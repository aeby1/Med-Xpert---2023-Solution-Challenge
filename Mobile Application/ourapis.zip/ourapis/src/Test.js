
// const axios = require('axios')

// var myArr = [];

// const options = {
//   method: 'GET',
//   url:
//     'https://google-maps28.p.rapidapi.com/maps/api/place/textsearch/json',
//   params: {
//     query: 'pharmacy',
//     location: '33.676317542300126,73.06723051534556',
//     type: 'pharmacy',
//     radius: '5000',
//     region: 'pk',
//     language: 'en'
//   },
//   headers: {
//     'X-RapidAPI-Key': 'b5b814646emshcb5b1315114d238p17aa82jsn702ff437127a',
//     'X-RapidAPI-Host': 'google-maps28.p.rapidapi.com'
//   }
// }

// axios
//   .request(options)
//   .then(function (response) {
//     var APIData = response.data["results"];
//     for (var i = 0; i < APIData.length; i++) {
//         var object = APIData[i];
//         myArr.push(
//           {
//             "name":object["name"],
//             "location":object["geometry"]["location"],
//             "user_rating":object["user_ratings_total"]
//           }
//         );
//       }
//       console.log(myArr);
//   })
//   .catch(function (error) {
//     console.error(error)
//   })


// const axios = require('axios');
// var ExactLocation = ""; 
  
// const options = {
//   method: 'GET',
//   url:
//     'https://www.mapquestapi.com/geocoding/v1/reverse?key=uUVgcxnWqrNNZhiOT87UlvGc5WY3hJiY&location='+33.67635855854314+','+73.06456674630101+'&includeRoadMetadata=true&includeNearestIntersection=true'
// }

// axios
//   .request(options)
//   .then(function (response) {
//     console.log(response.data["results"][0]["locations"]);
//     ExactLocation += response.data["results"][0]["locations"][0]["street"] + " ";
//     ExactLocation += response.data["results"][0]["locations"][0]["adminArea5"] + ", ";
//     ExactLocation += response.data["results"][0]["locations"][0]["adminArea1"];
//     console.log(ExactLocation);
//   })
//   .catch(function (error) {
//     console.error(error)
//   })     


var arrr = [];
for (var i = 0; i < 5; i++) {
  var myobj = {};
myobj["a"] = "sdsads";
myobj["b"] = "vnvd";
arrr.push(myobj)
}

; 
console.log(arrr);