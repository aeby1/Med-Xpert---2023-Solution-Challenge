const axios = require("axios");
var DoctorAroundMe = []
const options = {
  method: 'GET',
  url:
    'https://maps.googleapis.com/maps/api/place/nearbysearch/json',
  params: {
    location: '33.7803820992752,72.35205446097875',
    radius: '10000',
    opennow: 'open',
    type: 'doctor',
    key: 'AIzaSyBk_xLo4psRZvMHeXLiONkBAbKAtF5jWuc'
  },
  headers: { }
}

axios.request(options).then(function (response) {
	console.log(response.data);
    var APIData = response.data['results'];
    for (var i = 0; i < APIData.length; i++) {
        var NewObj = {};
        NewObj["name"] = APIData[i]["name"]; 
        if(APIData[i]["rating"]){
            NewObj["rating"] = APIData[i]["rating"];
        }
        else{
            NewObj["rating"] = "Not Rated Yet";
        }
        NewObj["location"] =   APIData[i]["location"]; 
        NewObj['address'] = APIData[i]['vicinity']
        DoctorAroundMe.push(NewObj);
    }
    console.log("Total Records Found: " + DoctorAroundMe.length);
    console.log(DoctorAroundMe);
}).catch(function (error) {
	console.error(error);
});