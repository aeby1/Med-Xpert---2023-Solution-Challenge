const axios = require("axios");
const options = {
  method: 'GET',
  url: 'https://newsapi.org/v2/everything?' +
  'q=Entertainment&' +
  'from=2022-11-01&' +
  'sortBy=popularity&' +
  'apiKey=fd5115e0a78f481390029204a948aae8',
};

axios.request(options).then(function (response) {
	console.log(response.data);
   
}).catch(function (error) {
	console.error(error);
});

