// const axios = require("axios");
// const options = {
//   url: 'https://quizapi.io/api/v1/questions?apiKey=6M4lbRBLzZbcub4zUHOPsHjXl1kV3K2N3V82fvZF&category=code&difficulty=Easy&limit=10',
// };

// axios.request(options).then(function (response) {
// 	console.log(response.data);
// }).catch(function (error) {
// 	console.error(error);
// });

let response = fetch(
    'https://quizapi.io/api/v1/questions?apiKey=6M4lbRBLzZbcub4zUHOPsHjXl1kV3K2N3V82fvZF&category=code&difficulty=Easy&limit=10'
  );
  let json = response.json();
  console.log(json);