const axios = require('axios')

var HospitalsNearMe = []

const options = {
  method: 'GET',
  url: 'https://google-maps28.p.rapidapi.com/maps/api/place/nearbysearch/json',
  params: {
    location: '33.675614252159775, 73.0672075580147',
    radius: '5000',
    language: 'en',
    type: 'hospital'
  },
  headers: {
    'X-RapidAPI-Key': 'b5b814646emshcb5b1315114d238p17aa82jsn702ff437127a',
    'X-RapidAPI-Host': 'google-maps28.p.rapidapi.com'
  }
}

axios
  .request(options)
  .then(function (response) {
    var APIData = response.data['results'];
    console.log(APIData);
    for (var i = 0; i < APIData.length; i++) {
        var NewObj = {};
        NewObj["name"] = APIData[i]["name"]; 
        NewObj["rating"] = APIData[i]["rating"]; 
        NewObj["location"] =   APIData[i]["geometry"]["location"]; 
        NewObj["address"] =   APIData[i]["vicinity"]; 
        HospitalsNearMe.push(NewObj);
    }
    console.log("Total Records Found: " + HospitalsNearMe.length);
    console.log(HospitalsNearMe);


  })
  .catch(function (error) {
    console.error(error)
  })
