const express = require('express')
const router = express.Router()
const mongoose = require('mongoose')
const PatientModel = require('../models/patient')

// Get All Patient 

router.get('/get_all_patient', (req, res, next) => {
  PatientModel.find()
  .then((result) => {
   res.status(200).json(
     {
       "Available Patients" : result
     }
   )
  })
  .catch((error)=>{
   console.log(error);
   res.status(500).json({
     Message: "Error in Fetching Patients data."+error
   })
  })


})

// Simple Index Get API

router.get('/', (req, res, next) => {
  res.status(500).json({
    Message: "Use Sepecific API to fetch data."
  })
})


// Post API Call To Add New Doctor

router.post('/register_patient/', async(req, res, next) => {
  console.log("Register");
  const patientMrId = "P"+Math.floor(Math.random() * 1000)+"-22";

  const newPatient = new PatientModel({
    _id: new mongoose.Types.ObjectId(),
    MrId: patientMrId,
    Cnic: req.body.Cnic,
    Name: req.body.Name,
    Telephone: req.body.Telephone,
    Email: req.body.Email,
    Age: req.body.Age,
    BloodGroup: req.body.BloodGroup,
    Password: req.body.Password,
  })

  newPatient.save()
  .then(result => {
    console.log("Patient SignUp SuccessFully.")
    console.log(result);
    res.status(200).json({
        newPatient : result
    })
  })

  .catch(err => {
    console.log(err);
    res.status(500).json({
        error: err
    })
  })

})

// Post API Call To Search Patient By Email

// router.post('/get_patient_by_email/:email', (req, res, next) => {
  // PatientModel.find({"Email":req.params.email})
  // .then((result) => {
  //  res.status(200).json(
  //    {
  //      "Patient Found" : result
  //    }
  //  )
  // })
//   .catch((error)=>{
//    console.log(error);
//    res.status(500).json({
//      Message: "Error in Fetching Patient data."+error
//    })
//   })

// })

// Post API Call To Search Patient By Email and Password

router.post('/LoginPatient/:Username/:Password', async(req, res, next) => {
  console.log(req.params);
  PatientModel.find({"Email":req.params.Username,"Password":req.params.Password})
  .then((result) => {
   if(result.length > 0){
     res.status(200).json(
       {
          "Patient Found" : result,
           "Message" : "True"
       }
     )
   }else{
   res.status(400).json(
     {
       "Message" : "False"
     }
   )
    }
  })
  .catch((error)=>{
   console.log(error);
   res.status(500).json({
     Message: "Error in Fetching Patient data."+error
   })
  })

})


// Post API Call To Login Patient

router.post('/get_patient_by_email/:email', (req, res, next) => {
  PatientModel.find({"Email":req.params.email})
  .then((result) => {
   res.status(200).json(
     {
       "Patient Found" : result
     }
   )
  })
  .catch((error)=>{
   console.log(error);
   res.status(500).json({
     Message: "Error in Fetching Patient data."+error
   })
  })

})


module.exports = router
