const fs = require("fs");
const { parse } = require("csv-parse");


Myarr = [];

async function myFunction() {
	fs.createReadStream("./medicines.csv")
  .pipe(parse({ delimiter: ",", from_line: 2 }))
  .on("data", function (row) {
	var MyObj = {};
	MyObj["medicine_name"] = row[0];
	MyObj["generic"] = row[1];
	Myarr.push(MyObj);
    // console.log(row);
  })
  
  .on("end", function () {
    console.log("finished");
  })
  .on("error", function (error) {
    console.log(error.message);
  });

  }
myFunction();

// wait 3 seconds
await new Promise((resolve, reject) => setTimeout(resolve, 10000));


console.log(Myarr);


  