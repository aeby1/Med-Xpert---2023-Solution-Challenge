const mongoose = require('mongoose');

const patientScheme = new mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    MrId: String,
    Cnic:{type:String,unique:true},
    Name:String,
    Telephone:{type:String,unique:true},
    Email:{type:String,unique:true},
    Age:String,
    BloodGroup:String,
    Password:String,
}
)

module.exports = mongoose.model('Patient',patientScheme);