const express = require('express');

const app = express();
const port = process.env.PORT || 3000;
require('./db/connection');
const bodyParser = require('body-parser');

const DoctorRoute = require('./routers/Doctor');
const PatientRoute = require('./routers/Patient');

app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());


app.use('/Doctor',DoctorRoute);
app.use('/Patient',PatientRoute);

app.use((req, res, next) => {
    res.send(400).json({
        Message: ' URL not found '
    })
});


app.listen(port,()=> {
    console.log('Server running at http://localhost:'+port);   
})