const mongoose = require('mongoose');

const doctorScheme = new mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    LicenseNo:{type:String,unique:true} ,
    FullName:String ,
    FatherName:String ,
    Degree:String ,
    Hospital: String,
    Department: String,
    PhoneNo: {type: String, unique:true} ,
    CNIC: {type: String, unique:true} ,
    Gender:String ,
    Email: {type: String, unique:true} ,
    Password:String,
}
)

module.exports = mongoose.model('Doctor',doctorScheme);