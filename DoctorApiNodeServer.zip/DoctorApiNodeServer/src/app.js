const express = require('express');
const cors = require("cors");

const app = express();
app.use(cors()); 
const port = process.env.PORT || 6969;
require('./Database/Connection');

const bodyParser = require('body-parser');

const DoctorRoute = require('./Router/Doctor');

app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());


app.use('/Doctor',DoctorRoute);

app.use((req, res, next) => {
    res.send(400).json({
        Message: ' URL not found '
    })
});


app.listen(port,()=> {
    console.log('Server running at https://localhost:'+port);   
})