const express = require('express')
const router = express.Router()
const mongoose = require('mongoose')

const DoctorModel = require('../Model/Doctor')
const PatientModel = require('../Model/Patient')

// Get All Doctor 

router.get('/get_all_doctor', (req, res, next) => {
  DoctorModel.find()
  .then((result) => {
   res.status(200).json(
     {
       "Available Doctors" : result
     }
   )
  })
  .catch((error)=>{
   console.log(error);
   res.status(500).json({
     Message: "Error in Fetching Doctors data."+error
   })
  })
})

// Post Request to Login The Doctor

router.post('/LoginDoctor/:Username/:Password', async(req, res, next) => {
  console.log(req.params);
  DoctorModel.find({"Email":req.params.Username,"Password":req.params.Password})
  .then((result) => {
   if(result.length > 0){
     res.status(200).json(
       {
          "Doctor Found" : result,
           "Message" : "True"
       }
     )
   }else{
   res.status(400).json(
     {
       "Message" : "False"
     }
   )
    }
  })
  .catch((error)=>{
   console.log(error);
   res.status(500).json({
     Message: "Error in Fetching Doctor data."+error
   })
  })
})



// Simple Index Get API

router.get('/', (req, res, next) => {
  res.status(500).json({
    Message: "Use Sepecific API to fetch data."
  })
})


// Post API Call To Add New Doctor

router.post('/SignUp/', (req, res, next) => {
  console.log('Doctor Signup Request is coming From React Js Project....')
  res.header("Access-Control-Allow-Origin", "*")
  const newDoctor = new DoctorModel({
    _id: new mongoose.Types.ObjectId(),
    LicenseNo: req.body.LicenseNo,
    FullName: req.body.FullName,
    FatherName: req.body.FatherName,
    Degree: req.body.Degree,
    Hospital: req.body.Hospital,
    Department: req.body.Department,
    PhoneNo: req.body.PhoneNo,
    CNIC: req.body.CNIC,
    Gender: req.body.Gender,
    Email: req.body.Email,
    Password:req.body.Password,
  })

  newDoctor.save()
  .then(result => {
    console.log(result);
    res.status(200).json({
        "Response": "Doctor SignUp SuccessFully."
    })
  })

  .catch(err => {
    console.log(err);
    res.status(500).json({
        error: err
    })
  })
  console.log('Doctor Signup Request is FullFill By The Server.....')
})

// Post API Call To Search Patient By MrId

router.post('/get_patient_by_mrid/:mrid', (req, res, next) => {
  console.log("Fetching data of patient.....");
  PatientModel.find({"MrId":req.params.mrid})
  .then((result) => {
   res.status(200).json(
     {
       "Patient Found" : result
     }
   )
  })
  .catch((error)=>{
   console.log(error);
   res.status(500).json({
     Message: "Error in Fetching Patient data."+error
   })
  })

})

// Post API Call To Search Doctor By Email

router.post('/get_doctor_by_email/:email', (req, res, next) => {
  DoctorModel.find({"Email":req.params.email})
  .then((result) => {
   res.status(200).json(
     {
       "Doctor Found" : result
     }
   )
  })
  .catch((error)=>{
   console.log(error);
   res.status(500).json({
     Message: "Error in Fetching Doctor data."+error
   })
  })

})

// Post API Call On Index Page

router.post('/', (req, res, next) => {
  res.status(500).json({
    Message: "Use Sepecific API to Post data."
  })
})

module.exports = router